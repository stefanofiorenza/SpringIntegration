package corso.spring.intgr.channels.demo.config;

public class SI100DemoConsts {

	public static final int messageToConsume=10;
	public static final long producerDelay=100L;
	public static final long consumerDelay=3000L;
	public static final int threadPoolSize=10;
}
