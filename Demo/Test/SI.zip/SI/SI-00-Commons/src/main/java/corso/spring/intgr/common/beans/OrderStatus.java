package corso.spring.intgr.common.beans;

public enum OrderStatus {

	REJECTED,
	ACCEPTED,
	EXECUTED;	
}
