package corso.spring.intgr.demo.basics.model;

import lombok.Data;

@Data
public class User {

	private String nome;
	private String cognome;
	private String email;
	private String telefono;
}
